﻿using System.Runtime;
using Banking.Logic;

namespace Banking.Logic;

public abstract class Account
{

    public abstract bool IsAllowed(Transaction t);
    public bool TryExecute(Transaction t)
    {
        if (IsAllowed(t))
        {

            t.Balance += t.Amount;
            System.Console.WriteLine($"Your new balance is {t.Balance}");
            return true;
        }
        return false;
    }
}

public class CheckingAccount : Account
{
    public override bool IsAllowed(Transaction t)
    {
        if (t.Balance > -10000 && t.Balance < 10000000)
        {

            if (t.Amount <= t.Balance)
            {
                return true;
            }
        }
        return false;
    }
}
public class BusinessAccount : Account
{
    public override bool IsAllowed(Transaction t)
    {
        if (t.Balance > -1000000 && t.Balance < 100000000)
        {

            if (t.Amount <= t.Balance)
            {
                return true;
            }
        }
        return false;
    }
}

public class SavingAccount : Account
{
    public override bool IsAllowed(Transaction t)
    {
        if (t.Balance > 0 && t.Balance < 100000000)
        {

            if (t.Amount <= t.Balance)
            {
                return true;
            }
        }
        return false;
    }
}
public class Transaction
{
    public string AccountNumber { get; set; }
    public decimal Amount { get; set; }
    public DateTime Timestap { get; set; }
    public string Description { get; set; }
    public decimal Balance { get; set; }

}