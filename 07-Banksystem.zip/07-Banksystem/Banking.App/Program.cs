﻿//https://github.com/rstropek/2023-24-2nd/tree/main/homeworks/2023-10-bank
using Banking.Logic;



Console.WriteLine("Welcome to the Banking App");

// Gather user input for account creation
Console.Write("Type of account (Checking, Business, or Savings): ");
string accountType = Console.ReadLine();
Console.Write("Account number: ");
string accountNumber = Console.ReadLine();
Console.Write("Account holder: ");
string accountHolder = Console.ReadLine();
Console.Write("Current balance: ");
decimal currentBalance = Convert.ToDecimal(Console.ReadLine());

// Create an instance of the appropriate account type
Account account;
switch (accountType.ToLower())
{
    case "checking":
        account = new CheckingAccount();
        break;
    case "business":
        account = new BusinessAccount();
        break;
    case "savings":
        account = new SavingsAccount();
        break;
    default:
        Console.WriteLine("Invalid account type.");
        return;
}

account.AccountNumber = accountNumber;
account.AccountHolder = accountHolder;
account.CurrentBalance = currentBalance;

// Gather user input for transaction
Console.Write("Transaction account number: ");
string transactionAccountNumber = Console.ReadLine();
Console.Write("Transaction description: ");
string transactionDescription = Console.ReadLine();
Console.Write("Transaction amount: ");
decimal transactionAmount = Convert.ToDecimal(Console.ReadLine());
Console.Write("Transaction timestamp: ");
DateTime transactionTimestamp = Convert.ToDateTime(Console.ReadLine());

// Create an instance of the Transaction class
Transaction transaction = new Transaction
{
    AccountNumber = transactionAccountNumber,
    Description = transactionDescription,
    Amount = transactionAmount,
   
};

// Check if the transaction is allowed
if (account.IsAllowed(transaction))
{
    // Execute the transaction
    if (account.TryExecute(transaction))
    {
        Console.WriteLine("Transaction executed successfully. The new current balance is " + account.CurrentBalance + "€.");
    }
    else
    {
        Console.WriteLine("Transaction execution failed.");
    }
}
else
{
    Console.WriteLine("Transaction is not allowed for this account.");
}
